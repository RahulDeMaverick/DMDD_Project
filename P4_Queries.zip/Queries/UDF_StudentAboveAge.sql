SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[studentaboveage]
(@stdid INT
)
RETURNS DATE
WITH SCHEMABINDING
AS
     BEGIN
         DECLARE @newdate DATE;
         SELECT @newdate = DATEADD(year, 25, [DOB])
         FROM [dbo].[student]
         WHERE studentID = @stdid;
         RETURN @newdate;
     END;
GO
