SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[BookRoom]
@newQty int ,  @hostelName varchar(60),@message varchar(100) OUTPUT, @oldcnt int
OUTPUT
AS
BEGIN
SET @oldcnt = (
select dbo.GetRoomOccupancy('@hostelName')
)
IF NOT EXISTS (
SELECT 1 from Hostel WHERE hostelName = @hostelName
)
SET @message = 'Invalid hostel Name'
ELSE IF EXISTS (

SELECT
CASE WHEN isnull(@oldcnt,0) >= isnull(@newQty,0) THEN @oldcnt ELSE @newQty END
)
BEGIN
UPDATE hostel set currentOccupancy = currentOccupancy + @newQty  where hostelName = @hostelName;
SET @message = 'Room booked in the selected hostel'
END;
ELSE IF EXISTS(
SELECT
CASE WHEN isnull(@oldcnt,0) <= isnull(@newQty,0) THEN @oldcnt ELSE @newQty END
)
BEGIN
SET @message = 'No room availeble in the selected hostel'
END
END
GO
