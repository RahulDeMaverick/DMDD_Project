use DMDD_TEAM17;

--/change datatype to varbinary/
alter table management 
add [Password] varbinary(400);

--/insertion of varchar type in varbinary/
update Management set [password]=convert(varbinary, '123@Akshay');

--/Setting up encryption key/
create MASTER KEY
ENCRYPTION BY PASSWORD = 'DMDD_TEAM17^';

CREATE CERTIFICATE AccountPass  
   WITH SUBJECT = 'Account Password';  
GO  

CREATE SYMMETRIC KEY AccountPassKey 
    WITH ALGORITHM = AES_256  
    ENCRYPTION BY CERTIFICATE AccountPass;  
GO  


--/Open key for encryption/
OPEN SYMMETRIC KEY AccountPassKey  
   DECRYPTION BY CERTIFICATE AccountPass;

--/Update query to encrypt column/
UPDATE management set [Password] = EncryptByKey(Key_GUID('AccountPassKey'),  convert(varbinary, [Password])) 
GO  

--/Decryption/
SELECT *, 
    CONVERT(varchar, DecryptByKey([Password]))   
    AS 'DecryptedPassword'  
    FROM management;  
GO  

--/Close key after excryption & decryption/
close symmetric key AccountPassKey;
select *from Management;