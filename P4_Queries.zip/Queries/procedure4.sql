SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[SP_InsertStudent] (

  @studentName nvarchar(45),
  @studentEmail varchar(100),
  @college varchar(60),
   @major varchar(45),
   @studentMobileNo char(10),
   @DOB date
) AS
BEGIN
    INSERT INTO Student (studentName, studentEmail, college,major,studentMobileNo,DOB )
    VALUES (@studentName, @studentEmail, @college,@major,@studentMobileNo,@DOB);

END
GO
