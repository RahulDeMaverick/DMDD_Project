SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetRoomOccupancy](
@hostelName varchar(60)
)
RETURNS INT
AS
BEGIN
DECLARE @room FLOAT
SELECT @room = CASE WHEN NOT EXISTS (SELECT SUM(maxOccupany - currentOccupancy) AS [available occupacy]
FROM Hostel where hostelName = @hostelName)
THEN NULL
ELSE
(SELECT SUM(maxOccupany - currentOccupancy) AS [available occupacy] FROM Hostel WHERE  hostelName = @hostelName)
END
RETURN @room
END
GO
