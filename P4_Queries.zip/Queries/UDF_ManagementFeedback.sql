SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[ManagementFeedback](
    @management_ID INT
)
RETURNS 
@FeedbackTable TABLE(
    Management VARCHAR(100),
    Poor INT,
    Fair INT,
    Good INT,
    Excellent INT
)
AS
BEGIN
    INSERT INTO @FeedbackTable
    SELECT DISTINCT
        managementID,
        (SELECT COUNT(*)
         WHERE fb.feedback = 'Poor' AND fb.managementID = @management_ID),

        (SELECT COUNT(*) 
        WHERE fb.feedback = 'Fair' AND fb.managementID = @management_ID),

        (SELECT COUNT(*) 
        WHERE fb.feedback = 'Good' AND fb.managementID = @management_ID),

        (SELECT COUNT(*) 
        WHERE fb.feedback = 'Excellent' AND fb.managementID = @management_ID)

        FROM feedback fb
        WHERE managementID = @management_ID
        GROUP BY managementID, fb.feedback, fb.feedback, fb.feedback, fb.feedback
        ORDER BY fb.managementID
    RETURN
END


GO
